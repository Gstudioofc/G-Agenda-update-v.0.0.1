package com.gstudio.agendax5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Ink = Color(0xFF0F172A)
private val Muted = Color(0xFF64748B)
private val Cyan = Color(0xFF00B8D4)
private val Violet = Color(0xFF7C4DFF)
private val Page = Color(0xFFF8FAFF)
private val Line = Color(0xFFE6EAF0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgendaX5App() }
    }
}

data class TaskItem(val id: String, val title: String, val time: String, val date: String, val category: String, val done: Boolean)

@Composable
private fun AgendaX5App() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("agenda_x5", 0) }
    var tasks by remember { mutableStateOf(loadTasks(prefs.getString("tasks", "[]") ?: "[]")) }
    fun persist(updated: List<TaskItem>) {
        tasks = updated
        prefs.edit().putString("tasks", JSONArray().apply {
            updated.forEach { t -> put(JSONObject().apply {
                put("id", t.id); put("title", t.title); put("time", t.time); put("date", t.date)
                put("category", t.category); put("done", t.done)
            }) }
        }.toString()).apply()
    }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    var page by remember { mutableStateOf("Hoje") }
    var showAdd by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var timerRunning by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(25 * 60) }
    LaunchedEffect(timerRunning) {
        while (timerRunning && seconds > 0) { delay(1000); seconds-- }
        if (seconds == 0) timerRunning = false
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Cyan, secondary = Violet, background = Page, surface = Color.White)) {
        Scaffold(containerColor = Page, bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                listOf("Hoje", "Agenda", "Jogo", "Perfil").forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item }, icon = {
                        Text(when (item) { "Hoje" -> "◷"; "Agenda" -> "▦"; "Jogo" -> "⚽"; else -> "◉" }, fontSize = 19.sp)
                    }, label = { Text(item, fontSize = 11.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet, indicatorColor = Color(0xFFEDE9FE)))
                }
            }
        }, floatingActionButton = {
            if (page == "Hoje" || page == "Agenda") FloatingActionButton(onClick = { showAdd = true }, containerColor = Ink, contentColor = Color.White, shape = CircleShape) { Text("+", fontSize = 28.sp) }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header(page)
                when (page) {
                    "Hoje" -> TodayScreen(tasks.filter { it.date == today }, seconds, timerRunning,
                        onToggleTimer = { timerRunning = !timerRunning }, onResetTimer = { timerRunning = false; seconds = 25 * 60 },
                        onToggleTask = { task -> persist(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }) }, onAdd = { showAdd = true })
                    "Agenda" -> AgendaScreen(tasks, today, onToggle = { task -> persist(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }) }, onDelete = { task -> persist(tasks.filterNot { it.id == task.id }) })
                    "Jogo" -> GameDayScreen()
                    else -> ProfileScreen(tasks.size, tasks.count { it.done })
                }
            }
        }
        if (showAdd) AddTaskDialog(onDismiss = { showAdd = false }, onSave = { title, time, date, category ->
            persist(tasks + TaskItem(UUID.randomUUID().toString(), title, time, date, category, false)); showAdd = false
        })
    }
}

private fun loadTasks(raw: String): List<TaskItem> = try {
    val array = JSONArray(raw)
    (0 until array.length()).map { i -> array.getJSONObject(i).let { o -> TaskItem(o.optString("id"), o.optString("title"), o.optString("time", "09:00"), o.optString("date"), o.optString("category", "Pessoal"), o.optBoolean("done")) } }
} catch (_: Exception) { emptyList() }

@Composable private fun Header(page: String) {
    Row(Modifier.fillMaxWidth().background(Page).padding(start = 22.dp, end = 22.dp, top = 20.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("AGENDA X5", fontSize = 11.sp, letterSpacing = 2.sp, color = Violet, fontWeight = FontWeight.ExtraBold)
            Text(when (page) { "Hoje" -> "Seu dia, no controle."; "Agenda" -> "Sua linha do tempo"; "Jogo" -> "Dia de Jogo"; else -> "Seu espaço" }, fontSize = 25.sp, color = Ink, fontWeight = FontWeight.ExtraBold)
        }
        Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Cyan, Violet)), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Text("X5", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp) }
    }
}

@Composable private fun TodayScreen(tasks: List<TaskItem>, seconds: Int, running: Boolean, onToggleTimer: () -> Unit, onResetTimer: () -> Unit, onToggleTask: (TaskItem) -> Unit, onAdd: () -> Unit) {
    val dateLabel = remember { SimpleDateFormat("EEEE, d 'de' MMMM", Locale("pt", "BR")).format(Date()).replaceFirstChar { it.uppercase() } }
    LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Column { Text(dateLabel, color = Muted, fontSize = 13.sp); Spacer(Modifier.height(5.dp)); Text("${tasks.size} tarefas • ${tasks.count { it.done }} concluídas", color = Muted, fontSize = 13.sp) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { QuickTile("◷", "Pomodoro", Modifier.weight(1f)); QuickTile("▦", "Timeline", Modifier.weight(1f)); QuickTile("⚽", "Dia de jogo", Modifier.weight(1f)) } }
        item {
            Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Ink, Color(0xFF25204A))), RoundedCornerShape(26.dp)).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("POMODORO", color = Cyan, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold); Text("Foco profundo", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Uma coisa de cada vez.", color = Color(0xFFCBD5E1), fontSize = 12.sp) }; Box(Modifier.size(82.dp).background(Color(0xFF302A55), CircleShape), contentAlignment = Alignment.Center) { Text(String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) } }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = onToggleTimer, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Ink), shape = RoundedCornerShape(30.dp)) { Text(if (running) "Pausar" else "Iniciar foco") }; OutlinedButton(onClick = onResetTimer, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF64748B)), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), shape = RoundedCornerShape(30.dp)) { Text("Reiniciar") } }
            }
        }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Próximas tarefas", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f)); Text("+ Adicionar", color = Violet, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onAdd() }) } }
        if (tasks.isEmpty()) item { EmptyCard("Seu dia está livre", "Adicione uma tarefa para começar a organizar seu tempo.") }
        items(tasks.sortedBy { it.time }, key = { it.id }) { TaskCard(it, { onToggleTask(it) }) }
        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable private fun AgendaScreen(tasks: List<TaskItem>, today: String, onToggle: (TaskItem) -> Unit, onDelete: (TaskItem) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Tudo o que você planejou, em um só lugar.", color = Muted, fontSize = 13.sp) }
        if (tasks.isEmpty()) item { EmptyCard("Sua agenda está vazia", "Toque no botão + para criar o primeiro compromisso.") }
        items(tasks.sortedWith(compareBy<TaskItem> { it.date }.thenBy { it.time }), key = { it.id }) { task ->
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(20.dp)).padding(14.dp)) {
                TaskCard(task, { onToggle(task) }, compact = true)
                Spacer(Modifier.height(8.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text("${task.date} • ${task.category}", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f)); Text("Excluir", color = Color(0xFFDC2626), fontSize = 12.sp, modifier = Modifier.clickable { onDelete(task) }) }
            }
        }
    }
}

@Composable private fun GameDayScreen() {
    LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Acompanhe os jogos que você não quer perder.", color = Muted, fontSize = 13.sp) }
        item { Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(24.dp)).padding(18.dp)) { Text("PRÓXIMO JOGO", color = Violet, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp); Spacer(Modifier.height(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { TeamBadge("PAL", Color(0xFF087A45)); Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) { Text("A definir", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("Data e horário", color = Muted, fontSize = 12.sp) }; TeamBadge("???", Color(0xFF64748B)) }; Spacer(Modifier.height(14.dp)); Text("Você pode usar esta área para organizar o dia de jogo. Acompanhar placares ao vivo exige uma fonte de dados externa, ainda não conectada.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp) } }
        item { EmptyCard("Prepare o seu dia de jogo", "Crie uma tarefa para lembrar do horário, preparar tudo e aproveitar a partida.") }
    }
}

@Composable private fun ProfileScreen(total: Int, done: Int) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(24.dp)).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(74.dp).background(Brush.linearGradient(listOf(Cyan, Violet)), CircleShape), contentAlignment = Alignment.Center) { Text("X5", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black) }; Spacer(Modifier.height(12.dp)); Text("Seu perfil", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("Organização começa com um passo.", color = Muted, fontSize = 12.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { StatCard("Tarefas", total.toString(), Modifier.weight(1f)); StatCard("Concluídas", done.toString(), Modifier.weight(1f)) }
        Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(20.dp)).padding(16.dp)) { Text("Sobre a Agenda X5", color = Ink, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("Versão nativa inicial. Seus compromissos ficam salvos localmente neste dispositivo.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp) }
    }
}

@Composable private fun QuickTile(icon: String, label: String, modifier: Modifier = Modifier) { Column(modifier.background(Color.White, RoundedCornerShape(18.dp)).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(36.dp).background(Brush.linearGradient(listOf(Cyan, Violet)), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text(icon, color = Color.White, fontSize = 19.sp) }; Spacer(Modifier.height(7.dp)); Text(label, color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis) } }

@Composable private fun TaskCard(task: TaskItem, onToggle: () -> Unit, compact: Boolean = false) {
    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(4.dp, 38.dp).background(if (task.done) Color(0xFF22C55E) else Cyan, RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(task.title, color = if (task.done) Muted else Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis); Spacer(Modifier.height(3.dp)); Text("${task.time}${if (compact) " • ${task.date}" else " • ${task.category}"}", color = Muted, fontSize = 11.sp) }
        Checkbox(checked = task.done, onCheckedChange = { onToggle() }, colors = CheckboxDefaults.colors(checkedColor = Violet, uncheckedColor = Color(0xFFCBD5E1)))
    }
}

@Composable private fun EmptyCard(title: String, body: String) { Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(22.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("✦", color = Violet, fontSize = 28.sp); Spacer(Modifier.height(8.dp)); Text(title, color = Ink, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(body, color = Muted, fontSize = 12.sp, lineHeight = 18.sp) } }
@Composable private fun StatCard(label: String, value: String, modifier: Modifier) { Column(modifier.background(Color.White, RoundedCornerShape(20.dp)).padding(18.dp)) { Text(value, color = Violet, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold); Text(label, color = Muted, fontSize = 12.sp) } }
@Composable private fun TeamBadge(name: String, color: Color) { Box(Modifier.size(54.dp).background(color, CircleShape), contentAlignment = Alignment.Center) { Text(name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp) } }

@Composable private fun AddTaskDialog(onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("09:00") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var category by remember { mutableStateOf("Pessoal") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Nova tarefa", fontWeight = FontWeight.Bold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("O que você precisa fazer?") }, singleLine = true)
            OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Horário (ex.: 14:30)") }, singleLine = true)
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Data (AAAA-MM-DD)") }, singleLine = true)
            Text("Categoria", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Pessoal", "Estudo", "Trabalho").forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 11.sp) }) } }
        }
    }, confirmButton = { TextButton(onClick = { if (title.isNotBlank() && time.matches(Regex("\\d{1,2}:\\d{2}")) && date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) onSave(title.trim(), time, date, category) }, enabled = title.isNotBlank()) { Text("Salvar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}
